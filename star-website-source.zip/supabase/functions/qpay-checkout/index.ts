import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": Deno.env.get("SITE_ORIGIN") ?? "null",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return json({ error: "Sign in required" }, 401);
    const url = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const admin = createClient(url, serviceKey);
    const userClient = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: authError } = await userClient.auth.getUser();
    if (authError || !user) return json({ error: "Sign in required" }, 401);

    const body = await req.json();
    const customer = body.customer ?? {};
    const items = Array.isArray(body.items) ? body.items : [];
    if (!items.length || items.length > 30) return json({ error: "Cart is empty or too large" }, 400);
    if (!customer.name?.trim() || !customer.phone?.trim() || !customer.address?.trim()) {
      return json({ error: "Name, phone, and delivery address are required" }, 400);
    }
    const requested = new Map<string, number>();
    for (const row of items) {
      if (typeof row.product_id !== "string" || !Number.isInteger(row.quantity) || row.quantity < 1 || row.quantity > 20) {
        return json({ error: "Invalid cart item" }, 400);
      }
      const nextQuantity = (requested.get(row.product_id) ?? 0) + row.quantity;
      if (nextQuantity > 20) return json({ error: "Maximum quantity per product is 20" }, 400);
      requested.set(row.product_id, nextQuantity);
    }
    const { data: products, error: productsError } = await admin.from("products")
      .select("id,name,price_mnt").in("id", [...requested.keys()]).eq("active", true);
    if (productsError || products?.length !== requested.size) return json({ error: "A product is unavailable" }, 400);

    const lines = products.map((p) => ({ ...p, quantity: requested.get(p.id)! }));
    const total = lines.reduce((sum, p) => sum + p.price_mnt * p.quantity, 0);
    const orderNumber = `STAR-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
    const { data: order, error: orderError } = await admin.from("orders").insert({
      user_id: user.id, order_number: orderNumber, total_mnt: total,
      customer_name: customer.name.trim(), phone: customer.phone.trim(), address: customer.address.trim(),
    }).select("id").single();
    if (orderError) throw orderError;
    const { error: itemError } = await admin.from("order_items").insert(lines.map((p) => ({
      order_id: order.id, product_id: p.id, product_name: p.name,
      unit_price_mnt: p.price_mnt, quantity: p.quantity,
      size: items.find((x: { product_id: string }) => x.product_id === p.id)?.size ?? null,
      color: items.find((x: { product_id: string }) => x.product_id === p.id)?.color ?? null,
    })));
    if (itemError) throw itemError;

    const clientId = Deno.env.get("QPAY_CLIENT_ID");
    const clientSecret = Deno.env.get("QPAY_CLIENT_SECRET");
    const invoiceCode = Deno.env.get("QPAY_INVOICE_CODE");
    if (!clientId || !clientSecret || !invoiceCode) throw new Error("QPay merchant secrets are not configured");
    const base = Deno.env.get("QPAY_BASE_URL") ?? "https://merchant-sandbox.qpay.mn";
    const tokenResponse = await fetch(`${base}/v2/auth/token`, {
      method: "POST", headers: { Authorization: `Basic ${btoa(`${clientId}:${clientSecret}`)}` },
    });
    if (!tokenResponse.ok) throw new Error("QPay authentication failed");
    const tokenData = await tokenResponse.json();
    const invoiceResponse = await fetch(`${base}/v2/invoice`, {
      method: "POST",
      headers: { Authorization: `Bearer ${tokenData.access_token}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        invoice_code: invoiceCode, sender_invoice_no: orderNumber,
        invoice_receiver_code: user.id, invoice_description: `STAR order ${orderNumber}`,
        amount: total, callback_url: `${url}/functions/v1/qpay-callback`,
      }),
    });
    const invoice = await invoiceResponse.json();
    if (!invoiceResponse.ok || !invoice.invoice_id) throw new Error(invoice.message ?? "Could not create QPay invoice");
    const { error: updateError } = await admin.from("orders").update({
      qpay_invoice_id: invoice.invoice_id, qpay_qr_text: invoice.qr_text ?? null,
      qpay_qr_image: invoice.qr_image ?? null, qpay_urls: invoice.urls ?? [],
    }).eq("id", order.id);
    if (updateError) throw updateError;
    return json({ order_id: order.id, order_number: orderNumber, total_mnt: total,
      qr_text: invoice.qr_text, qr_image: invoice.qr_image, urls: invoice.urls ?? [] });
  } catch (error) {
    console.error("qpay-checkout error", error);
    return json({ error: error instanceof Error ? error.message : "Checkout failed" }, 500);
  }
});
