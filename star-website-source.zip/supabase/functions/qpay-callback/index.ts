import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  try {
    const body = await req.json();
    const invoiceId = body.invoice_id ?? body.object_id;
    if (!invoiceId) return new Response("Missing invoice id", { status: 400 });
    const base = Deno.env.get("QPAY_BASE_URL") ?? "https://merchant-sandbox.qpay.mn";
    const basic = btoa(`${Deno.env.get("QPAY_CLIENT_ID")}:${Deno.env.get("QPAY_CLIENT_SECRET")}`);
    const tokenResponse = await fetch(`${base}/v2/auth/token`, {
      method: "POST", headers: { Authorization: `Basic ${basic}` },
    });
    if (!tokenResponse.ok) throw new Error("QPay authentication failed");
    const { access_token } = await tokenResponse.json();
    const checkResponse = await fetch(`${base}/v2/payment/check`, {
      method: "POST", headers: { Authorization: `Bearer ${access_token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ object_type: "INVOICE", object_id: invoiceId }),
    });
    const payment = await checkResponse.json();
    if (!checkResponse.ok) throw new Error("QPay payment check failed");

    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: order, error } = await admin.from("orders").select("id,total_mnt,status")
      .eq("qpay_invoice_id", invoiceId).single();
    if (error || !order) return new Response("Order not found", { status: 404 });
    const rows = payment.rows ?? [];
    const paidAmount = Number(payment.paid_amount ?? 0);
    const confirmed = Number(payment.count ?? rows.length) > 0 &&
      paidAmount === order.total_mnt &&
      rows.some((row: { payment_status?: string; payment_currency?: string }) =>
        row.payment_status === "PAID" && row.payment_currency === "MNT"
      );
    if (confirmed && order.status !== "paid") {
      await admin.from("orders").update({ status: "paid", paid_at: new Date().toISOString(),
        qpay_payment_id: rows[0]?.payment_id ?? null }).eq("id", order.id);
    }
    return new Response("OK", { status: 200 });
  } catch (error) {
    console.error("qpay-callback error", error);
    return new Response("Payment verification failed", { status: 500 });
  }
});
