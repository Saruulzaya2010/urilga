-- STAR shop data model. Run with Supabase migrations after creating a project.
create extension if not exists pgcrypto;

create table if not exists public.products (
  id text primary key,
  name text not null,
  category text not null,
  price_mnt integer not null check (price_mnt > 0),
  image_path text not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.wishlist (
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id text not null references public.products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);

create table if not exists public.cart_items (
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id text not null references public.products(id) on delete cascade,
  quantity integer not null check (quantity between 1 and 20),
  size text,
  color text,
  updated_at timestamptz not null default now(),
  primary key (user_id, product_id)
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  order_number text not null unique,
  status text not null default 'pending_payment'
    check (status in ('pending_payment','paid','payment_failed','cancelled','fulfilled')),
  total_mnt integer not null check (total_mnt > 0),
  customer_name text not null,
  phone text not null,
  address text not null,
  qpay_invoice_id text unique,
  qpay_payment_id text,
  qpay_qr_text text,
  qpay_qr_image text,
  qpay_urls jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  paid_at timestamptz
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id text references public.products(id) on delete set null,
  product_name text not null,
  unit_price_mnt integer not null check (unit_price_mnt > 0),
  quantity integer not null check (quantity between 1 and 20),
  size text,
  color text
);

create index if not exists orders_user_created_idx on public.orders(user_id, created_at desc);
create index if not exists order_items_order_idx on public.order_items(order_id);

alter table public.products enable row level security;
alter table public.wishlist enable row level security;
alter table public.cart_items enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

revoke all on public.products, public.wishlist, public.cart_items, public.orders, public.order_items from anon, authenticated;
grant select on public.products to anon, authenticated;
grant select, insert, delete on public.wishlist to authenticated;
grant select, insert, update, delete on public.cart_items to authenticated;
grant select on public.orders, public.order_items to authenticated;

create policy "Active products are public" on public.products for select to anon, authenticated using (active);
create policy "Users view their saved products" on public.wishlist for select to authenticated using ((select auth.uid()) = user_id);
create policy "Users save their own products" on public.wishlist for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "Users remove their own saved products" on public.wishlist for delete to authenticated using ((select auth.uid()) = user_id);
create policy "Users manage their own cart" on public.cart_items for all to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "Users view their own orders" on public.orders for select to authenticated using ((select auth.uid()) = user_id);
create policy "Users view items in their own orders" on public.order_items for select to authenticated using (
  exists (select 1 from public.orders o where o.id = order_id and o.user_id = (select auth.uid()))
);

insert into public.products (id,name,category,price_mnt,image_path) values
('tops-0','Everyday cotton tee','Tops & shirts',48900,'photo-1551163943-3f6a855d1153'),
('tops-1','Soft knit top','Tops & shirts',68900,'photo-1576566588028-4147f3842f27'),
('tops-2','Ribbed tank','Tops & shirts',39900,'photo-1564257577-6a0b6d6f6c8a'),
('tops-3','Relaxed shirt','Tops & shirts',79900,'photo-1583743814966-8936f5b7be1a'),
('bottoms-0','The straight jean','Bottoms',119900,'photo-1594633312681-425c7b97ccd1'),
('bottoms-1','Easy linen trouser','Bottoms',108900,'photo-1506629905607-d9c297d1c3a2'),
('bottoms-2','Relaxed denim','Bottoms',129900,'photo-1541099649105-f69ad21f3246'),
('bottoms-3','Soft pleated pant','Bottoms',99900,'photo-1582418702059-97eb5d0b9f25'),
('outerwear-0','Weekend trench','Outerwear',189900,'photo-1548126032-079a0fb0099d'),
('outerwear-1','The soft blazer','Outerwear',169900,'photo-1539533018447-63fcce2678e3'),
('outerwear-2','Everyday jacket','Outerwear',149900,'photo-1548624149-f5cdbf6e2b5b'),
('outerwear-3','Long wool coat','Outerwear',219900,'photo-1544022613-e87ca75a784a'),
('accessories-0','Everyday shoulder bag','Accessories',89900,'photo-1584917865442-de89df76afd3'),
('accessories-1','Sculpted hoops','Accessories',42900,'photo-1611652022419-a9419f74343d'),
('accessories-2','Minimal watch','Accessories',119900,'photo-1523275335684-37898b6baf30'),
('accessories-3','Soft silk scarf','Accessories',55900,'photo-1529139574466-a303027c1d8b'),
('shoes-0','Ballet flat','Shoes',139900,'photo-1543163521-1bf539c55dd2'),
('shoes-1','City sneaker','Shoes',159900,'photo-1542291026-7eec264c27ff'),
('shoes-2','The little heel','Shoes',149900,'photo-1543163521-1bf539c55dd2'),
('shoes-3','Weekend runner','Shoes',169900,'photo-1542291026-7eec264c27ff')
on conflict (id) do update set name=excluded.name,category=excluded.category,price_mnt=excluded.price_mnt,image_path=excluded.image_path;
