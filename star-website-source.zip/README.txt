STAR дэлгүүрийн сайт — эх код

Засварлах:
1. Энэ хавтсыг Visual Studio Code эсвэл Visual Studio дээр нээнэ.
2. index.html нь хуудасны бүтэц, бичвэрүүдийг агуулна.
3. style.css нь өнгө, хэмжээ, харагдацыг агуулна.
4. script.js нь цэс, нэвтрэх цонх, сагс болон хадгалах үйлдлүүдийг агуулна.
5. Өөрчлөлтөө хадгалаад index.html файлыг хөтөч дээр нээнэ.

Файлуудыг нэг хавтаст нь хамт байлгана.

Жинхэнэ backend асаах:
- backend-config.js дотор Supabase Project URL болон public anon key тохируулна.
- supabase/migrations/ файлын SQL migration-ийг Supabase дээр ажиллуулна.
- QPay нууц утгуудыг backend-ийн Edge Function secrets хэсэгт хадгална. Нууц түлхүүрийг HTML/JavaScript файлд бүү оруул.
- Төслийг HTTPS домэйнд байршуулж QPay production merchant эрх авсны дараа л бодит төлбөр хүлээн авна.
- Дэлгэрэнгүй алхмууд SETUP.md файлд бий.
