# STAR — Supabase + QPay холболтын заавар

Одоогийн HTML загвар Supabase тохиргоогүй үед demo горимд ажиллана. Жинхэнэ хэрэглэгчийн бүртгэл, хадгалсан бараа, сагс, захиалгын түүх болон QPay төлбөр ажиллуулахын тулд доорх өөрийн эзэмшлийн дансууд шаардлагатай. Энэ багц backend-ийн код, схем, RLS хамгаалалт болон QPay Edge Functions-ийг бэлдсэн; cloud дансанд байршуулж, төлбөрийн эрхээ авсны дараа л бодит захиалга ажиллана.

## 1. Supabase төсөл

1. Supabase дээр өөрийн account-аар төсөл үүсгэнэ.
2. Project Settings → API хэсгээс **Project URL** болон **anon/public key**-г авна.
3. `backend-config.js` файлд эдгээр хоёрыг байрлуулна. **secret/service_role** key-г энд бүү хий.
4. SQL Editor дээр `supabase/migrations/202610010001_store.sql` файлын SQL-г ажиллуулна.
5. Authentication → URL Configuration хэсэгт сайт байрших HTTPS домэйныг Site URL болон Redirect URLs-д нэмнэ. Email confirmation, production-д өөрийн SMTP тохиргоог хийнэ.

## 2. QPay merchant эрх

QPay-д merchant/invoice эрх хүсэж, эхлээд sandbox `client_id`, `client_secret`, `invoice_code` авна. Production-д QPay-ийн гэрээ, production credentials болон production API орчин тусад нь хэрэгтэй. Эдгээр нууц утгыг browser талын `backend-config.js` файлд хэзээ ч бүү тавь.

## 3. Backend functions байрлуулах

Өөрийн компьютер дээр Supabase CLI ашиглана:

```sh
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase functions deploy qpay-checkout
supabase functions deploy qpay-callback
```

Supabase Dashboard → Edge Functions → Secrets хэсэгт дараах утгуудыг нууц байдлаар нэмнэ:

- `QPAY_CLIENT_ID`
- `QPAY_CLIENT_SECRET`
- `QPAY_INVOICE_CODE`
- `QPAY_BASE_URL` = sandbox-д `https://merchant-sandbox.qpay.mn`; production merchant баталгаажсаны дараа `https://merchant.qpay.mn`
- `SITE_ORIGIN` = сайт ажиллах яг origin, жишээ `https://shop.example.mn` (локал туршилтад Live Server-ийн origin)

`SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`-г Supabase Edge Functions-ийн project secrets доторх автоматаар өгөгдсөн утгаар ашиглана. Хэрэв таны төсөл эдгээрийг автоматаар өгөхгүй бол Dashboard-аас зөв нэртэй secret болгон нэмнэ. Service role key-г зөвхөн server secret-д хадгална.

## 4. Сайтыг байршуулах ба турших

1. `outputs` хавтсыг HTTPS дэмждэг static hosting дээр байршуулна. HTML файлыг `file://` замаар нээхэд auth redirect болон callback найдвартай ажиллахгүй.
2. Supabase Auth redirect тохиргоо, `SITE_ORIGIN`, `backend-config.js` дахь URL/key гурвын домэйн ижил байгаа эсэхийг шалгана.
3. QPay sandbox QR-аар тест төлбөр хийнэ. Callback нь QPay-ийн `/v2/payment/check` үр дүнг нягталж, дүн таарсан үед захиалгыг `paid` төлөвт шилжүүлнэ. Албан ёсны заавар callback-ийн дараа төлбөр шалгахыг шаарддаг.
4. Бүх туршилт амжилттай болсны дараа QPay production merchant эрхээр production URL болон secrets-г солино.

## Өгөгдлийн сан

- `products`: дэлгүүрийн demo бараа, server талын бодит үнэ
- `wishlist`: хэрэглэгчийн хадгалсан зүйлс
- `cart_items`: хэрэглэгчийн сагс
- `orders`, `order_items`: хаяг, үнийн snapshot, QPay invoice/payment болон захиалгын түүх
- Хүснэгт бүр RLS-тэй. Browser-оос захиалга болон төлбөрийн төлөв бичих эрх олгоогүй; checkout зөвхөн Edge Function-ээр үнэ тооцно.

Одоогоор барааны demo зураг/нэр/үнэ хадгалагдсан. Жинхэнэ бараа, үлдэгдэл, буцаалт, eBarimt болон хүргэлтийн үнэ/үйл ажиллагааг бизнесийн бодит нөхцөлөөр нэмж тохируулна. Бодит төлбөрийг зөвхөн QPay production эрх баталгаажсаны дараа идэвхжүүл.
