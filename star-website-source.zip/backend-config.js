// Supabase-ийн Project URL, anon/public key утгыг оруулна.
// ЭНД QPay client secret эсвэл Supabase service_role түлхүүрийг ХЭЗЭЭ Ч хийхгүй.
window.STAR_CONFIG = {
  supabaseUrl: "",
  supabaseAnonKey: "",
};
